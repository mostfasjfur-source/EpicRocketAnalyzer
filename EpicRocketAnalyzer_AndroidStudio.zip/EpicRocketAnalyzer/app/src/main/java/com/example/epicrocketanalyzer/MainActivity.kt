package com.example.epicrocketanalyzer

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
    private val requestCapture = 7001
    private lateinit var status: TextView
    private lateinit var results: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 24)
            setBackgroundColor(Color.rgb(16, 24, 38))
        }
        fun label(text: String, size: Float = 18f) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(Color.WHITE)
            setPadding(0, 12, 0, 12)
        }
        layout.addView(label("🚀 محلّل Epic Rocket", 26f))
        layout.addView(label("قارئ نتائج الشاشة — تجريبي"))
        status = label("الحالة: متوقف")
        layout.addView(status)
        val start = Button(this).apply { text = "بدء قراءة الشاشة" }
        layout.addView(start)
        val stop = Button(this).apply { text = "إيقاف القراءة" }
        layout.addView(stop)
        layout.addView(label("النتائج المقروءة:"))
        results = label("لا توجد نتائج بعد")
        layout.addView(results)
        layout.addView(label("ملاحظة: وافق على مشاركة الشاشة من نافذة Android. القراءة تلتقط النص الظاهر فقط ولا تتنبأ بالنتيجة القادمة.", 14f))
        setContentView(ScrollView(this).apply { addView(layout) })

        start.setOnClickListener {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
        }
        stop.setOnClickListener {
            stopService(Intent(this, CaptureService::class.java))
            status.text = "الحالة: متوقف"
        }
        CaptureService.onText = { found ->
            runOnUiThread {
                if (found.isNotBlank()) {
                    val prefs = getSharedPreferences("history", MODE_PRIVATE)
                    val old = prefs.getString("items", "") ?: ""
                    val lines = (old.lines() + found.lines()).filter { it.isNotBlank() }.distinct().takeLast(100)
                    prefs.edit().putString("items", lines.joinToString("\n")).apply()
                    results.text = lines.asReversed().joinToString("\n")
                }
            }
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("data", data)
            }
            startForegroundService(service)
            status.text = "الحالة: يقرأ الشاشة"
        }
    }
}
