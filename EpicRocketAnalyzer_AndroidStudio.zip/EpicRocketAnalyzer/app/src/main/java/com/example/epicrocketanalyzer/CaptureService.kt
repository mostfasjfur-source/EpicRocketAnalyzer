package com.example.epicrocketanalyzer

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService : Service() {
    companion object { @Volatile var onText: ((String) -> Unit)? = null }
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var thread: HandlerThread? = null
    private val busy = AtomicBoolean(false)
    private var lastSnapshot = ""
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotification()
        val code = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: return START_NOT_STICKY
        val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra("data", Intent::class.java)
                   else @Suppress("DEPRECATION") (intent.getParcelableExtra("data") as? Intent)
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)
        startCapture()
        return START_NOT_STICKY
    }

    private fun createNotification() {
        val channel = "rocket_capture"
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(channel, "قراءة الشاشة", NotificationManager.IMPORTANCE_LOW))
        }
        val n = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channel).setContentTitle("Epic Rocket Analyzer")
                .setContentText("قراءة الشاشة مفعّلة").setSmallIcon(android.R.drawable.ic_menu_view).build()
        else Notification.Builder(this).setContentTitle("Epic Rocket Analyzer")
            .setContentText("قراءة الشاشة مفعّلة").setSmallIcon(android.R.drawable.ic_menu_view).build()
        startForeground(44, n)
    }

    private fun startCapture() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val w = metrics.widthPixels; val h = metrics.heightPixels; val dpi = metrics.densityDpi
        thread = HandlerThread("screen-ocr").also { it.start() }
        val handler = Handler(thread!!.looper)
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader!!.setOnImageAvailableListener({ r ->
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            if (!busy.compareAndSet(false, true)) { image.close(); return@setOnImageAvailableListener }
            process(image)
        }, handler)
        display = projection?.createVirtualDisplay("RocketOCR", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
    }

    private fun process(image: Image) {
        try {
            val bitmap = imageToBitmap(image)
            image.close()
            val input = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(input).addOnSuccessListener { result ->
                val matches = Regex("""(?<!\d)(\d{1,4}(?:[.,]\d{1,3})?)\s*[xX×]""")
                    .findAll(result.text).map { it.groupValues[1].replace(',', '.') + "x" }.toList()
                val snapshot = matches.joinToString("\n")
                if (snapshot.isNotBlank() && snapshot != lastSnapshot) {
                    lastSnapshot = snapshot
                    onText?.invoke(snapshot)
                }
            }.addOnCompleteListener { bitmap.recycle(); busy.set(false) }
        } catch (_: Exception) { try { image.close() } catch (_: Exception) {}; busy.set(false) }
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val padded = Bitmap.createBitmap(image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(plane.buffer)
        val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        padded.recycle()
        return cropped
    }

    override fun onDestroy() {
        display?.release(); reader?.close(); projection?.stop()
        thread?.quitSafely()
        recognizer.close()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
